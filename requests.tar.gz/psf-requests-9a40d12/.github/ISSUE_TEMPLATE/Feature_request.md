---
name: Feature request
about: Suggest an idea for this project
labels:
- "Feature Request"
- "actions/autoclose-feat"

---

Requests is not accepting feature requests at this time.
